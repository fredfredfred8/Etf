import streamlit as st
import pandas as pd

st.set_page_config(page_title="ETF Signal Assistant", layout="centered")

st.title("📈 ETF Signal Assistant")
st.subheader("Kaufsignale basierend auf politischen & wirtschaftlichen Ereignissen")

# ETF Übersicht
st.header("Live ETF Übersicht")
etfs = {
    "ETF": ["ARKK", "SOXX", "INDA", "EEM", "ICLN"],
    "Kurs (fiktiv)": [55.20, 210.75, 48.10, 39.85, 18.40],
    "Signal": ["Kaufen", "Halten", "Beobachten", "Kaufen", "Verkauf bald"]
}
df = pd.DataFrame(etfs)
st.dataframe(df)

# Politische Ereignisse
st.header("Politische & wirtschaftliche Ereignisse")
st.markdown("""
- **20. Mai**: Fed senkt Leitzins → Tech positiv  
- **18. Mai**: Indisches BIP wächst stark → INDA positiv  
- **17. Mai**: KI-Förderpaket in USA → ARKK & SOXX positiv
""")

# Empfehlungen
st.header("Empfehlungen")
st.markdown("""
- **ARKK**: Kaufen  
- **EEM**: Kaufen  
- **ICLN**: Beobachten
""")

st.caption("Demo-Version – keine Finanzberatung")
